// Variables
const welcomeScreen = document.getElementById("welcome-screen");
const gameScreen = document.getElementById("game-screen");
const board = document.getElementById("board");
const cells = document.querySelectorAll(".cell");
const winnerMessage = document.getElementById("winner-message");
const winnerText = document.getElementById("winner-text");
const restartButton = document.getElementById("restart-button");
const backButton = document.getElementById("back-button");
const playAIButton = document.getElementById("play-ai");
const playFriendButton = document.getElementById("play-friend");

let currentPlayer = "x";
let isGameOver = false;

// Game Modes
playAIButton.addEventListener("click", () => startGame("ai"));
playFriendButton.addEventListener("click", () => startGame("friend"));

function startGame(mode) {
  welcomeScreen.classList.add("hidden");
  gameScreen.classList.remove("hidden");
  document.getElementById("game-mode-title").textContent =
    mode === "ai" ? "Player vs AI" : "X vs O";
  resetBoard();
}

backButton.addEventListener("click", () => {
  gameScreen.classList.add("hidden");
  welcomeScreen.classList.remove("hidden");
  resetBoard();
});

// Game Logic
cells.forEach((cell) => {
  cell.addEventListener("click", () => {
    if (cell.textContent !== "" || isGameOver) return;

    cell.textContent = currentPlayer.toUpperCase();
    cell.classList.add(currentPlayer);

    if (checkWinner(currentPlayer)) {
      winnerText.textContent = `${currentPlayer.toUpperCase()} Wins!`;
      winnerMessage.classList.remove("hidden");
      isGameOver = true;
    } else if (Array.from(cells).every((cell) => cell.textContent !== "")) {
      winnerText.textContent = "It's a Draw!";
      winnerMessage.classList.remove("hidden");
      isGameOver = true;
    } else {
      currentPlayer = currentPlayer === "x" ? "o" : "x";
    }
  });
});

restartButton.addEventListener("click", resetBoard);

function resetBoard() {
  cells.forEach((cell) => {
    cell.textContent = "";
    cell.classList.remove("x", "o");
  });
  currentPlayer = "x";
  isGameOver = false;
  winnerMessage.classList.add("hidden");
}

// Check Winner
function checkWinner(player) {
  const winningCombos = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

  return winningCombos.some((combo) =>
    combo.every((index) => cells[index].classList.contains(player))
  );
}
